// For Firebase JS SDK v7.20.0 and later, measurementId is optional
import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';
//import firebase from "firebase";

const firebaseConfig = {
  apiKey: "AIzaSyDeMzzDhkPT9QZ0_Y_ecTrvkbZMTiI_FRg",
  authDomain: "clone-2b3a0.firebaseapp.com",
  projectId: "clone-2b3a0",
  storageBucket: "clone-2b3a0.appspot.com",
  messagingSenderId: "456445739902",
  appId: "1:456445739902:web:79eef6dec0476c2faca92f",
  measurementId: "G-JPXH0SESB8"
};

const firebaseApp = firebase.initializeApp(firebaseConfig);
// initialize the database
const db = firebaseApp.firestore();
// for authentication
const auth = firebase.auth();
export { db, auth };